//Footer for the homepage
export default function Footer(){
    return(
        <div className="home-footer">
        Copyright © ConnectIt, India. All rights reserved.
    </div>
    )
    
}