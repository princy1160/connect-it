//All the constants used throughout the app declared here

export const APP_NAME = 'ConnectIt';
export const APP_URL = 'https://connect-it-chat-video-calls.netlify.app';
export const BACKEND_URL='http://localhost:5000';
