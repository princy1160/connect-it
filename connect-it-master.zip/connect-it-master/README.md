# ConnectIt

ConnectIt is a user-friendly online meeting platform that enables easy and direct communication. It provides a simple interface for chatting before, during, and after calls. Creating chat rooms and joining calls is quick and effortless. It promotes productive conversations by allowing note-taking during meetings and collaborative work on a virtual whiteboard. The whiteboard can be downloaded for future reference
